/* SPDX-License-Identifier: (GPL-2.0-only OR BSD-2-Clause) */

#ifndef __LINUX_SIZES_H__
#define __LINUX_SIZES_H__

#define SZ_32K				0x00008000

#endif
